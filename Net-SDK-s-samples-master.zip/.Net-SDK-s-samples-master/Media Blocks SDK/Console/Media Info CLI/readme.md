# Media Blocks SDK .Net - Media Info CLI demo

Media Info CLI demo is a command line application that uses the Media Blocks SDK .Net to get information about media files.

## Features

- Get information about media files
- Get information about network streams

## Supported frameworks

- .Net 4.7.2
- .Net Core 3.1
- .Net 5
- .Net 6
- .Net 7

---

[Media Blocks SDK .Net product page](https://www.visioforge.com/media-blocks-sdk)