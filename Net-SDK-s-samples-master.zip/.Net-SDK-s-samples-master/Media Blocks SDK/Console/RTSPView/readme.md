# Media Blocks SDK .Net - RTSP View CLI demo

RTSP View CLI demo is a command line application that uses the Media Blocks SDK .Net to play the RTSP stream from the IP camera.

## Supported frameworks

- .Net 4.7.2
- .Net Core 3.1
- .Net 5
- .Net 6
- .Net 7

---

[Media Blocks SDK .Net product page](https://www.visioforge.com/media-blocks-sdk)