# Media Blocks SDK .Net - Face Detector Live Demo (WPF)

Face Detector Live Demo is an application that uses the Media Blocks SDK .Net to detect faces in live video.

## Features

- Face detection
- Video preview

## Supported frameworks

- .Net 4.7.2
- .Net Core 3.1
- .Net 5
- .Net 6
- .Net 7

---

[Media Blocks SDK .Net product page](https://www.visioforge.com/media-blocks-sdk)
