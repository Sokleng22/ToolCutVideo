# Media Blocks SDK .Net - KLV Demo (WPF)

This demo shows how to demux and mux KLV data into MPEG-TS files.

## Features

- Demux and mux KLV data into MPEG-TS files

## Supported frameworks

- .Net 4.7.2
- .Net Core 3.1
- .Net 5
- .Net 6
- .Net 7

---

[Media Blocks SDK .Net product page](https://www.visioforge.com/media-blocks-sdk)
