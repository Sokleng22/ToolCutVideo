# Media Blocks SDK .Net - VNC Source Demo (WPF)

VNC Source Demo is an application that uses the Media Blocks SDK .Net to play video from the VNC/RFB source in WPF applications.

## Features

- Play video from VNC/RFB source

## Supported frameworks

- .Net 4.7.2
- .Net Core 3.1
- .Net 5
- .Net 6
- .Net 7

---

[Media Blocks SDK .Net product page](https://www.visioforge.com/media-blocks-sdk)
