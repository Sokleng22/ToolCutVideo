﻿# VisioForge Media Player SDK .Net

## Karaoke demo (C#/WinForms)

Karaoke audio files playback demo application.

[Visit the product page.](https://www.visioforge.com/media-player-sdk-net)