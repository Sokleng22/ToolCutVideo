# Media Blocks SDK .Net - Simple Video Capture Demo (WinForms)

Simple Video Capture Demo is an application that uses the Media Blocks SDK .Net to capture video from webcams in WinForms applications.

## Features

- Capture video from webcams to MP4 file
- Video preview

## Supported frameworks

- .Net 4.7.2
- .Net Core 3.1
- .Net 5
- .Net 6
- .Net 7

---

[Media Blocks SDK .Net product page](https://www.visioforge.com/media-blocks-sdk)
