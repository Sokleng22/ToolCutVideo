﻿# VisioForge Media Player SDK .Net

## Skinned Player Demo (C#/WPF)

The demo shows skinned interface usage of the Media Player SDK .Net. 

You can:
* audio and video files playback
* network sources playback
* skinned interface

[Visit the product page.](https://www.visioforge.com/media-player-sdk-net)

## Supported frameworks

* .Net 4.7.2
* .Net Core 3.1
* .Net 5
* .Net 6
* .Net 7