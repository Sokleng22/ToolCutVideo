﻿# VisioForge Media Player SDK .Net

## Memory Playback Demo (C#/WinForms)

The demo app shows a video/audio playback from a memory buffer/stream.

[Visit the product page.](https://www.visioforge.com/media-player-sdk-net)