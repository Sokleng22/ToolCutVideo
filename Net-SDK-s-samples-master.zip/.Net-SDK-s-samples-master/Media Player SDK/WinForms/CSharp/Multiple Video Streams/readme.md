﻿# VisioForge Media Player SDK .Net

## Multiple Video Streams Demo (C#/WinForms)

The demo app shows how to play a video file that contains several video streams.

[Visit the product page.](https://www.visioforge.com/media-player-sdk-net)

## Supported frameworks

* .Net 4.7.2
* .Net Core 3.1
* .Net 5
* .Net 6
* .Net 7