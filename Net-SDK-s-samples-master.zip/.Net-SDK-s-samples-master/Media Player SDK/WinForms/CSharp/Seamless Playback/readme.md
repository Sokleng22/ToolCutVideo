﻿# VisioForge Media Player SDK .Net

## Seamless Playback Demo (C#/WinForms)

The demo app shows how to switch between video files seamlessly with a pause.

[Visit the product page.](https://www.visioforge.com/media-player-sdk-net)

## Supported frameworks

* .Net 4.7.2
* .Net Core 3.1
* .Net 5
* .Net 6
* .Net 7