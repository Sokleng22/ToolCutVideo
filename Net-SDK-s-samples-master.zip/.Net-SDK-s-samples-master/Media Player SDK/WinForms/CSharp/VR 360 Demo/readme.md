﻿# VisioForge Media Player SDK .Net

## VR 360 Demo (C#/WinForms)

The demo app shows how to play VR 360-degree files.

[Visit the product page.](https://www.visioforge.com/media-player-sdk-net)

## Supported frameworks

* .Net 4.7.2
* .Net Core 3.1
* .Net 5
* .Net 6
* .Net 7