﻿# VisioForge Media Player SDK .Net

## Read file info code snippet (C#/WinForms)

The code snippet shows how to read video and audio file information, including stream information, metadata, and tags.

[Visit the product page.](https://www.visioforge.com/media-player-sdk-net)

## Supported frameworks

* .Net 4.7.2
* .Net Core 3.1
* .Net 5
* .Net 6
* .Net 7
